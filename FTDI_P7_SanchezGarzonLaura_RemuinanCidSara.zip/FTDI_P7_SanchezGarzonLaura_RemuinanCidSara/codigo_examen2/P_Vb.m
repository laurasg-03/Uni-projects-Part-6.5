%% Aproximaciones a la realización de filtros morfológicos
clc
clear all
close all
% La aplicación de filtros morfológicos es una aproximación no lineal

% Dilatación: situar el origen del kernel sobre el píxel considerado y hallar el 
% máximo de los valores del entorno de dicho píxel que coinciden con ceros 
%(valor oscuro o unidad en binario) del kernel utilizado.

[ima,map]=imread('bandas.bmp');
mask=[1 1 1 1 1;1 1 1 1 1; 1 1 1 0 0;1 1 1 0 0; 1 1 1 0 0];
mask=uint8(mask);

ima_res_dil=imfilter_dilate(ima,mask);
ima_res_er=imfilter_erode(ima,mask);

figure('Name', 'Aplicación de dilatación');
subplot(1,2,1); imshow(ima); title(sprintf('Ima original; E=%g', calcular_energia(ima))); colorbar;
subplot(1,2,2); imshow(ima_res_dil); title(sprintf('Ima dilatada, X; E=%g', calcular_energia(ima_res_dil))); colorbar;

figure('Name', 'Aplicación de erosión');
subplot(1,2,1); imshow(ima); title(sprintf('Ima original; E=%g', calcular_energia(ima))); colorbar;
subplot(1,2,2); imshow(ima_res_er); title(sprintf('Ima dilatada, X; E=%g', calcular_energia(ima_res_er))); colorbar;

%% Dilatación y erosión por desplazamiento de la señal
clc
clear all
close all

[ima,map]=imread('bandas.bmp');
mask=[1 1 1 1 1;1 1 1 1 1; 1 1 1 0 0;1 1 1 0 0; 1 1 1 0 0];
mask=uint8(mask);

ima_res_dil=imfilter_dilateD(ima,mask);
ima_res_er=imfilter_erodeD(ima,mask);

figure('Name', 'Aplicación de dilatación');
subplot(1,2,1); imshow(ima); title(sprintf('Ima original; E=%g', calcular_energia(ima))); colorbar;
subplot(1,2,2); imshow(ima_res_dil); title(sprintf('Ima dilatada, X; E=%g', calcular_energia(ima_res_dil))); colorbar;

figure('Name', 'Aplicación de erosión');
subplot(1,2,1); imshow(ima); title(sprintf('Ima original; E=%g', calcular_energia(ima))); colorbar;
subplot(1,2,2); imshow(ima_res_er); title(sprintf('Ima dilatada, X; E=%g', calcular_energia(ima_res_er))); colorbar;


%% Combinación de operadores morfológicos básicos
clc 
close all
clear all

% Funciones de matlab ya creadas (imdilate; imerode)
%se = strel('square',3); % creación de un elemento estructurante 3x3 cuadrado
%ima_d=imdilate(ima,se); % dilatacion de la imagen ima
%ima_e=imerode (ima,se); % erosion de la imagen ima

% GRADIENTE MORFOLÓGICO --> sacar bordes de los objetos
% Gradiente por dilatación: dilatacion - x
% Gradiente por erosión: x - erosión
% Gradiente morfológico: dilatacion - erosión

[ima,map]=imread('Tools.bmp');

b = strel('square',3); % creación de un elemento estructurante 3x3 cuadrado
ima_d=imdilate(ima,b); % dilatacion de la imagen ima
ima_e=imerode (ima,b); % erosion de la imagen ima

figure('Name', 'Aplicación de dilatación y erosión usando las funciones de matlab');
subplot(1,3,1); imshow(ima); title(sprintf('Ima original; E=%g', calcular_energia(ima))); colorbar;
subplot(1,3,2); imshow(ima_d); title(sprintf('Ima dilatada, X; E=%g', calcular_energia(ima_d))); colorbar;
subplot(1,3,3); imshow(ima_e); title(sprintf('Ima erosionada, X; E=%g', calcular_energia(ima_e))); colorbar;

ima_grad_dil=ima_d-ima; % Gradiente por dilatación
ima_grad_ero=ima-ima_e; % Gradiente por erosión
ima_grad_morf=ima_d-ima_e; % Gradiente morfológico

figure('Name', 'Aplicación de dilatación y erosión usando las funciones de matlab');
subplot(2,2,1); imshow(ima); title(sprintf('Ima original; E=%g', calcular_energia(ima))); colorbar;
subplot(2,2,2); imshow(ima_grad_dil); title(sprintf('Ima gradiente por dilatación, X; E=%g', calcular_energia(ima_grad_dil))); colorbar;
subplot(2,2,3); imshow(ima_grad_ero); title(sprintf('Ima gradiente por erosión, X; E=%g', calcular_energia(ima_grad_ero))); colorbar;
subplot(2,2,4); imshow(ima_grad_morf); title(sprintf('Ima gradiente morfológico, X; E=%g', calcular_energia(ima_grad_morf))); colorbar;

% APERTURA Y CIERRE
b = strel('square',3); 
ima_e=imerode (ima,b); ima_apertura=imdilate(ima_e,b); % Apertura ((x er b) dil b)
ima_d=imdilate(ima,b); ima_cierre=imerode(ima_d,b); % Cierre

figure('Name', 'Aplicación de apertura y cierre');
subplot(1,3,1); imshow(ima); title(sprintf('Ima original; E=%g', calcular_energia(ima))); colorbar;
subplot(1,3,2); imshow(ima_apertura); title(sprintf('Apertura, X; E=%g', calcular_energia(ima_apertura))); colorbar;
subplot(1,3,3); imshow(ima_cierre); title(sprintf('Cierre, X; E=%g', calcular_energia(ima_cierre))); colorbar;


% Dilatación y Apertura:
	% Dilatación:
        % Objetivo: Aumentar el tamaño de las regiones blancas en la imagen.
        % Efecto visual: Expande las áreas blancas, conecta componentes y llena pequeños agujeros.
	% Apertura:
        % Secuencia: Erosión seguida de dilatación.
        % Objetivo: Suavizar los contornos, eliminar pequeños detalles y separar objetos cercanos.
        % Efecto visual: Elimina pequeños detalles, huecos y afina los bordes.

          % Visualmente:
                % En la dilatación, las regiones blancas se expanden y se conectan.
                % En la apertura, pequeños detalles se eliminan, y las regiones blancas se suavizan
                
% Erosión y Cierre:
    % Erosión:
        % Objetivo: Reducir el tamaño de las regiones blancas en la imagen.
        % Efecto visual: Contrae las áreas blancas, separa componentes y elimina pequeños detalles.
    % Cierre:
        % Secuencia: Dilatación seguida de erosión.
        % Objetivo: Unir brechas en los contornos, cerrar pequeños agujeros y conectar objetos cercanos.
        % Efecto visual: Cierra huecos y suaviza los bordes.

            % Visualmente:
                % En la erosión, las regiones blancas se contraen y se separan.
                % En el cierre, pequeños huecos se cierran y los contornos se suavizan.

                
% Restauración de un cuadro por apertura
% Realice operaciones de apertura sobre la imagen con distintos elementos estructurantes en forma y tamaño hasta conseguir eliminar el trazo blanco realizado sobre el cuadro.
clc
close all
clear all
[ima,map]=imread('MRI_gray_garab.jpg');

b1 = strel('square',3); % Cuadrado: resultados estándar
b2 = strel('disk', 3); % Disco: cuando se desean transiciones suaves en lugar de bordes angulares.
b3 = strel('line', 5, 0); % Línea horizontal: afectar principalmente componentes en la dirección horizontal
b4 = strel('line', 5, 90); % Línea vertical
b5 = strel('line', 5, 45); % Línea diagonal
b6 = strel('diamond', 3); % Diamante: operaciones que necesitan una forma más suave que el cuadrado, pero más extrema que el disco.
b7 = strel('octagon', 3); % Octágono: Cuando se desea una forma que combine suavidad con la capacidad de cubrir múltiples direcciones.

line_horizontal = strel('line', 3, 0); % Elemento de línea horizontal
line_vertical = strel('line', 3, 90); % Elemento de línea vertical
b = strel('arbitrary', [0 1 0; 1 1 1; 0 1 0]); % Cruz: cuando se desean efectos combinados de dilatación y erosión en varias direcciones.


ima_e=imerode (ima,b7); ima_apertura=imdilate(ima_e,b7); % Apertura ((x er b) dil b)

% Se eliminan con el disco, el diamante y el octágono
figure('Name', 'Aplicación de dilatación y erosión usando las funciones de matlab');
subplot(1,2,1); imshow(ima); title(sprintf('Ima original; E=%g', calcular_energia(ima))); colorbar;
subplot(1,2,2); imshow(ima_apertura); title(sprintf('Ima a la que se le ha aplicado apertura; E=%g', calcular_energia(ima_apertura))); colorbar;


%% Eliminación de valla por cierre
% Realice operaciones de cierre sobre la imagen con distintos elementos estructurantes en forma y tamaño hasta conseguir eliminar el mallado negro entre las verjas de la imagen
clc
close all
clear all

[ima,map]=imread('verjanegra.jpg');

b1 = strel('square',3); 
b2 = strel('disk', 3);
b3 = strel('line', 5, 0); %línea horizontal: en la erosión, elimina componentes verticales
b4 = strel('line', 5, 90); %línea vertical
b5 = strel('line', 5, 45); %línea diagonal
b6 = strel('diamond', 3);
b7 = strel('octagon', 3);

line_horizontal = strel('line', 3, 0); % Elemento de línea horizontal
line_vertical = strel('line', 3, 90); % Elemento de línea vertical
b = strel('arbitrary', [0 1 0; 1 1 1; 0 1 0]); % Cruz

ima_d=imdilate(ima,b7); ima_cierre=imerode(ima_d,b7);% Cierre

% Se eliminan con el cuadrado, disco, cruz y el octágono
figure('Name', 'Aplicación de dilatación y erosión usando las funciones de matlab');
subplot(1,2,1); imshow(ima); title(sprintf('Ima original; E=%g', calcular_energia(ima))); colorbar;
subplot(1,2,2); imshow(ima_cierre); title(sprintf('Ima a la que se le ha aplicado cierre; E=%g', calcular_energia(ima_cierre))); colorbar;



%%
function ima_res=imfilter_dilate(ima,mask)

ima=uint8(ima); % Para asegurarse de que el tipo es uint8 ([0,255])
[image_h,image_w,~] = size(ima); % Dimensiones de la imagen. con ~ ignoramos el numero de canales

[M,N] = size(mask); % Dimensiones del kernel
margen_y = (M-1) / 2; % Encontrar cuánto se sale el kernel
margen_x = (N-1) / 2;

mask=uint8(255*fliplr(flipud(mask))); % Reflejo vertical y horizontal del kernel. Multiplicar por 255 es una forma de convertir esos valores binarios en el rango [0, 255] sin cambiar la lógica de la operación.

ima_res = uint8(zeros(image_h,image_w)); % inicialización de la imagen resultante

for f=margen_y+1:image_h-margen_y, % excluir filas y columnas que pertenecen al margen
    for c=margen_x+1:image_w-margen_x,
        
        simage = ima(f-margen_y:f+margen_y , c-margen_x:c+margen_x); % f-margen_y es el índice de la primera fila de la región en la que podemos trabajar
        
        and_image=bitand(simage,mask); % Operación AND
        
        ima_res(f,c) = max(max(and_image)); % Se asigna el máximo valor a la imagen que se está creando

    end;
end;
% sustituir los valores no calculados --> donde no se pudo aplicar kernel
ima_res(1:margen_y,:) = ima(1:margen_y,:); % se sustituyen las primeras filas de ima_res con las primeras filas de la imagen original ima
ima_res(end-margen_y+1:end,:) = ima(end-margen_y+1:end,:);
ima_res(:,1:margen_x) = ima(:,1:margen_x);
ima_res(:,end-margen_x+1:end) = ima(:,end-margen_x+1:end);
end

function ima_res=imfilter_erode(ima,mask)

ima=uint8(ima);
[image_h,image_w,~] = size(ima);

[M,N] = size(mask);
margen_y = (M-1) / 2;
margen_x = (N-1) / 2;

mask=uint8(255*(~mask)); % Pasamos los ceros a unos y viceversa

ima_res = uint8(zeros(image_h,image_w));

for f=margen_y+1:image_h-margen_y,
    for c=margen_x+1:image_w-margen_x,
        
        simage = ima( f-margen_y:f+margen_y , c-margen_x:c+margen_x);
        
        or_image=bitor(simage,mask);
        
        ima_res(f,c) = min(min(or_image));

    end;
end;
% sustituir los valores no calculados
ima_res(1:margen_y,:) = ima(1:margen_y,:);
ima_res(end-margen_y+1:end,:) = ima(end-margen_y+1:end,:);
ima_res(:,1:margen_x) = ima(:,1:margen_x);
ima_res(:,end-margen_x+1:end) = ima(:,end-margen_x+1:end);
end

%%
function energia = calcular_energia(imagen)

imagen=double(imagen); % para evitar desbordamientos en caso de unit, logical, ...
energia = sum(sum(imagen .* imagen));

% Si la imagen tiene múltiples canales (por ejemplo, RGB), sumar las energías de cada canal
if size(imagen, 3) > 1
    energia = sum(energia(:));
end

end

%%
function ima_res=imfilter_dilateD(ima,mask)
ima=uint8(ima); 
[image_h,image_w,~] = size(ima);
[M,N] = size(mask); % tamaño máscara acorde al tamaño de la imagen

mask_center_y =ceil((M) / 2); % El centro del kernel
mask_center_x=ceil((N) / 2); % ceil se utiliza para redondear hacia arriba en caso de que las dimensiones del kernel sean impares
margen_y=(M-1)/2; % Margen del kernel
margen_x=(N-1)/2;
mask=uint8(255*fliplr(flipud(mask))); % Se hace el espejo vertical y horizontalmente
ima_anterior = 0.*ima;
% imagen auxiliar inicializada con píxeles blancos, del mismo tamaño que la imagen original (image_h x image_w). 
% Se utiliza para rastrear la dilatación a medida que se desplaza el kernel

for i=1:M %Recorre filas del kernel
    for j=1:N % Recorre columnas del kernel
        if mask(i,j)==255 % Si se trata de un pixel blanco --> dilatamos
            shift_vector=[mask_center_y-i, mask_center_x-j]; % Crea un vector de desplazamiento --> determina cuánto se desplazará la imagen en la dirección vertical y horizontal
            ima_despl = circshift(ima, shift_vector); % Desplazar ima sobr el vector de desplazamiento
            ima_res=max(ima_anterior,ima_despl); % Realiza la operación de dilatación al tomar el valor máximo pixel a pixel entre la imagen desplazada y la imagen resultante acumulada hasta ahora
            % Esto asegura que se conserve el valor máximo en cada posición a medida que se desplaza el kernel
            ima_anterior=ima_res; % Actualiza la imagen anterior con la imagen resultante después de cada desplazamiento
        end
    end
end
% sustituir los valores no calculados
ima_res(1:margen_y,:) = ima(1:margen_y,:);
ima_res(end-margen_y+1:end,:) = ima(end-margen_y+1:end,:);
ima_res(:,1:margen_x) = ima(:,1:margen_x);
ima_res(:,end-margen_x+1:end) = ima(:,end-margen_x+1:end);
end

function ima_res=imfilter_erodeD(ima,mask)
ima=uint8(ima); 
[image_h,image_w,~] = size(ima);
[M,N] = size(mask);
% El centro del kernel
mask_center_y =ceil((M) / 2);
mask_center_x=ceil((N) / 2);
margen_y=(M-1)/2;
margen_x=(N-1)/2;
mask=uint8(255*mask);
ima_anterior=uint8(255*ones(image_h,image_w));

for i=1:M
    for j=1:N
        if mask(i,j)==255
            shift_vector=[mask_center_y-i, mask_center_x-j];
            ima_despl = circshift(ima, shift_vector);
            ima_res=min(ima_anterior,ima_despl); % Toma el valor mínimo entre los píxeles, preservando los valores más bajos. Esto resulta en una contracción de las áreas blancas en la imagen.
            ima_anterior=ima_res;
        end
    end
end
% sustituir los valores no calculados
ima_res(1:margen_y,:) = ima(1:margen_y,:);
ima_res(end-margen_y+1:end,:) = ima(end-margen_y+1:end,:);
ima_res(:,1:margen_x) = ima(:,1:margen_x);
ima_res(:,end-margen_x+1:end) = ima(:,end-margen_x+1:end);
end
