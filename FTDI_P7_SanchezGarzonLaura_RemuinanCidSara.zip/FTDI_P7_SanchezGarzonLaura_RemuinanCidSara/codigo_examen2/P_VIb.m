%% RESTAURACIÓN LINEAL
% Recuperar una imagen que ha sido degradada de una manera conocida
% El método consiste en modelar la degradación y aplicar el proceso inverso. 

% a. Restauración lineal en ausencia de ruido
% La imagen original i ha sido filtrada con una máscara h
% o=i*h; n=0 (ruido de la señal);
% Trabajamos en el dominio frecuencial: I=O/H; I --> ift --> i

% b.  