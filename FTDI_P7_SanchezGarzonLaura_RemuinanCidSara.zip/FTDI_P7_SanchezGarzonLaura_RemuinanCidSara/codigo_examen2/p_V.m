%% Aplicación de operadores locales lineales 
clc
clear all
close all

% Op. local toma como entrada el valor de un entorno de píxeles (M' x N') y genera un valor resultante en el píxel homólogo de la imagen resultante.

% FILTRADO LINEAL
% Si un operador local efectúa una transformación lineal, su comportamiento puede definirse completamente por su respuesta al impulso, h[n,m]
   % Si la respuesta al impulso es rectangular y simétrica respecto de su origen (para lo cual 𝑀′, 𝑁′ han de ser impares)--> aplicación sobre la imagen: w[n,m]=h[-n,-m] sobre cada píxel de la imagen original
     % Matlab ofrece imfilter. Para evitar problemas de truncamiento --> double

[ima, map] = imread('MRI_pseudo_colored.jpg'); 
ima=double(ima);
a= [7 6 4 1 4 6 7]; c=sum(a);
W=[zeros(1,7);zeros(1,7);zeros(1,7);a;zeros(1,7);zeros(1,7);zeros(1,7)]/c;

ima_res=imfilter(ima,W); 
ima_res_t=imfilter(ima,W'); 

figure('Name', 'Aplicación de operadores locales lineales');
subplot(1,3,1); imshow(uint8(ima)); title(sprintf('Ima original; E=%g', calcular_energia(ima))); colorbar;
subplot(1,3,2); imshow(uint8(ima_res)); title(sprintf('Ima suavizada, X; E=%g', calcular_energia(ima_res))); colorbar;
subplot(1,3,3); imshow(uint8(ima_res_t)); title(sprintf('Ima suavizada con el kernel traspuesto, X; E=%g', calcular_energia(ima_res_t))); colorbar;

ima_res_sym=imfilter(ima,W,'symmetric'); 
ima_res_rep=imfilter(ima,W,'replicate'); 
ima_res_circ=imfilter(ima,W,'circular'); 

ima_res_sym_t=imfilter(ima,W','symmetric'); 
ima_res_rep_t=imfilter(ima,W','replicate'); 
ima_res_circ_t=imfilter(ima,W','circular'); 

figure('Name', 'Observar qué pasa en los bordes');
subplot(2,3,1); imshow(uint8(ima_res_sym)); title(sprintf('Im suav, sim; E=%g', calcular_energia(ima_res_sym))); colorbar;
subplot(2,3,2); imshow(uint8(ima_res_rep)); title(sprintf('Ima suav, repl; E=%g', calcular_energia(ima_res_rep))); colorbar;
subplot(2,3,3); imshow(uint8(ima_res_circ)); title(sprintf('Ima suav, circ; E=%g', calcular_energia(ima_res_circ))); colorbar;

subplot(2,3,4); imshow(uint8(ima_res_sym_t)); title(sprintf('Im suav, sim; E=%g', calcular_energia(ima_res_sym_t))); colorbar;
subplot(2,3,5); imshow(uint8(ima_res_rep_t)); title(sprintf('Ima suav, repl; E=%g', calcular_energia(ima_res_t))); colorbar;
subplot(2,3,6); imshow(uint8(ima_res_circ_t)); title(sprintf('Ima suav, circ; E=%g', calcular_energia(ima_res_circ_t))); colorbar;

%% Filtros habituales
%% SUAVIZADO
clc
clear all
close all

[ima, map] = imread('MRI_pseudo_colored.jpg'); 
ima=double(ima);
c=9;
W=[ones(1,3);ones(1,3);ones(1,3)]/c;
ima_res=imfilter(ima,W); 

figure('Name', 'Suavizado con filtro de media');
subplot(1,2,1); imshow(uint8(ima)); title(sprintf('Ima original; E=%g', calcular_energia(ima))); colorbar;
subplot(1,2,2); imshow(uint8(ima_res)); title(sprintf('Ima suavizada, X; E=%g', calcular_energia(ima_res))); colorbar;

% Imágenes diferencia (una por canal)
r1 = double(ima_res(:,:,1)); 
g1 = double(ima_res(:,:,2)); 
b1 = double(ima_res(:,:,3)); 

r2 = double(ima(:,:,1)); 
g2 = double(ima(:,:,2)); 
b2 = double(ima(:,:,3)); 

rdif = (r1-r2).^2; 
gdif = (g1-g2).^2; 
bdif = (b1-b2).^2; 

figure('Name', 'Imágenes diferencia (una por canal)');
subplot(1,3,1); imagesc(rdif); colormap(gray); title(sprintf('Ima suavT, X; E=%g', calcular_energia(rdif))); colorbar;
subplot(1,3,2); imagesc(gdif); title(sprintf('Im suav, sim; E=%g', calcular_energia(gdif))); colorbar;
subplot(1,3,3); imagesc(bdif); title(sprintf('Ima suav, repl; E=%g', calcular_energia(bdif))); colorbar;

c_5=5^2;
W_5=[ones(1,5);ones(1,5);ones(1,5);ones(1,5);ones(1,5)]/c_5;
ima_res_5=imfilter(ima,W_5); 

c_7=7^2;
W_7=[ones(1,7);ones(1,7);ones(1,7);ones(1,7);ones(1,7);ones(1,7);ones(1,7)]/c_7;
ima_res_7=imfilter(ima,W_7); 

figure('Name', 'Comparación del suavizado de imágenes');
subplot(1,3,1); imshow(uint8(ima_res)); title(sprintf('filtro 3x3; E=%g', calcular_energia(ima_res))); colorbar;
subplot(1,3,2); imshow(uint8(ima_res_5)); title(sprintf('filtro 5x5, X; E=%g', calcular_energia(ima_res_5))); colorbar;
subplot(1,3,3); imshow(uint8(ima_res_7)); title(sprintf('filtro 7x7, X; E=%g', calcular_energia(ima_res_7))); colorbar;

r1 = double(ima(:,:,1)); 
g1 = double(ima(:,:,2)); 
b1 = double(ima(:,:,3)); 

r23 = double(ima_res(:,:,1)); 
g23 = double(ima_res(:,:,2)); 
b23 = double(ima_res(:,:,3)); 

r25 = double(ima_res_5(:,:,1)); 
g25 = double(ima_res_5(:,:,2)); 
b25 = double(ima_res_5(:,:,3)); 

r27 = double(ima_res_7(:,:,1)); 
g27 = double(ima_res_7(:,:,2)); 
b27 = double(ima_res_7(:,:,3)); 

% Imágenes diferencia

rdif3 = (r1-r23).^2; 
gdif3 = (g1-g23).^2; 
bdif3 = (b1-b23).^2; 

rdif5 = (r1-r25).^2; 
gdif5 = (g1-g25).^2; 
bdif5 = (b1-b25).^2; 

rdif7 = (r1-r27).^2; 
gdif7 = (g1-g27).^2; 
bdif7 = (b1-b27).^2; 

figure('Name', 'comparación suavizado de imágenes. Imágenes diferencia (una por canal)');
subplot(3,3,1); imagesc(uint8(rdif3)); title(sprintf('Ima diferencia, canal rojo, orden 3; E=%g', calcular_energia(rdif3))); colorbar;
subplot(3,3,2); imagesc(uint8(gdif3)); title(sprintf('Ima diferencia, canal verde, orden 3; E=%g', calcular_energia(gdif3))); colorbar;
subplot(3,3,3); imagesc(uint8(bdif3)); title(sprintf('Ima diferencia, canal azul, orden 3; E=%g', calcular_energia(bdif3))); colorbar;
subplot(3,3,4); imagesc(uint8(rdif5)); title(sprintf('Ima diferencia, canal rojo, orden 5; E=%g', calcular_energia(rdif5))); colorbar;
subplot(3,3,5); imagesc(uint8(gdif5)); title(sprintf('Ima diferencia, canal verde, orden 5; E=%g', calcular_energia(gdif5))); colorbar;
subplot(3,3,6); imagesc(uint8(bdif5)); title(sprintf('Ima diferencia, canal azul, orden 5; E=%g', calcular_energia(bdif5))); colorbar;
subplot(3,3,7); imagesc(uint8(rdif7)); title(sprintf('Ima diferencia, canal rojo, orden 7; E=%g', calcular_energia(rdif7))); colorbar;
subplot(3,3,8); imagesc(uint8(gdif7)); title(sprintf('Ima diferencia, canal verde, orden 7; E=%g', calcular_energia(gdif7))); colorbar;
subplot(3,3,9); imagesc(uint8(bdif7)); title(sprintf('Ima diferencia, canal azul, orden 7; E=%g', calcular_energia(bdif7))); colorbar;

% APLICACIÓN DE IMFILTER_BINOMIAL
ima_res_orden3=imfilter_binomial(ima,3);
ima_res_orden5=imfilter_binomial(ima,5);
ima_res_orden7=imfilter_binomial(ima,7);

figure('Name', 'Aplicación de imfilter_binomial');
subplot(1,3,1); imagesc(uint8(ima_res_orden3)); title(sprintf('Orden 3; E=%g', calcular_energia(ima_res_orden3))); colorbar;
subplot(1,3,2); imagesc(uint8(ima_res_orden5)); title(sprintf('Orden 5; E=%g', calcular_energia(ima_res_orden5))); colorbar;
subplot(1,3,3); imagesc(uint8(ima_res_orden7)); title(sprintf('Orden 7, repl; E=%g', calcular_energia(ima_res_orden7))); colorbar;




%% EXTRACCIÓN DE CONTORNOS
clc
clear all
close all
[ima, map] = imread('Hernia_disco.jpg'); 
ima=double(ima);

% Filtros habituales: Roberts 
Rx=[1 0; 0 -1]; Ry=[0 1; -1 0];
ima_res_rx=imfilter(ima,Rx); ima_res_ry=imfilter(ima,Ry); 
R=sqrt(ima_res_rx.^2 + ima_res_ry.^2);

figure('Name', 'Bordes utilizando Roberts');
subplot(2,2,1); imagesc(uint8(ima)); colormap(gray); title(sprintf('imagen original; E=%g', calcular_energia(ima))); colorbar;
subplot(2,2,2); imagesc(uint8(R)); colormap(gray); title(sprintf('Gradiente; E=%g', calcular_energia(R))); colorbar;
subplot(2,2,3); imagesc(uint8(ima_res_rx+128)); colormap(gray); title(sprintf('Prewitt_y (bordes horizontales); E=%g', calcular_energia(ima_res_rx))); colorbar;
subplot(2,2,4); imagesc(uint8(ima_res_ry+128)); colormap(gray); title(sprintf('Prewitt_x (bordes verticales); E=%g', calcular_energia(ima_res_ry))); colorbar;

% Filtros habituales: Prewitt
Px=[1 1 1; 0 0 0; -1 -1 -1]/6; Py=[-1 0 1; -1 0 1; -1 0 1]/6;
ima_res_px=imfilter(ima,Px); ima_res_py=imfilter(ima,Py); 
P=sqrt(ima_res_px.^2 + ima_res_py.^2);

figure('Name', 'Bordes utilizando Prewitt');
subplot(2,2,1); imagesc(uint8(ima)); colormap(gray); title(sprintf('imagen original; E=%g', calcular_energia(ima))); colorbar;
subplot(2,2,2); imagesc(uint8(P)); colormap(gray); title(sprintf('Gradiente; E=%g', calcular_energia(P))); colorbar;
subplot(2,2,3); imagesc(uint8(ima_res_px+128)); colormap(gray); title(sprintf('Prewitt_y (bordes horizontales); E=%g', calcular_energia(ima_res_px))); colorbar;
subplot(2,2,4); imagesc(uint8(ima_res_py+128)); colormap(gray); title(sprintf('Prewitt_x (bordes verticales); E=%g', calcular_energia(ima_res_py))); colorbar;

% Filtros habituales: Sobel 
Sx=[1 2 1; 0 0 0; -1 -2 -1]/8; Sy=[-1 0 1; -2 0 2; -1 0 1]/8;
ima_res_sx=imfilter(ima,Sx); ima_res_sy=imfilter(ima,Sy); 
S=sqrt(ima_res_sx.^2 + ima_res_sy.^2);

figure('Name', 'Bordes utilizando Sobel');
subplot(2,2,1); imagesc(uint8(ima)); colormap(gray); title(sprintf('imagen original; E=%g', calcular_energia(ima))); colorbar;
subplot(2,2,2); imagesc(uint8(S)); colormap(gray); title(sprintf('Gradiente; E=%g', calcular_energia(S))); colorbar;
subplot(2,2,3); imagesc(uint8(ima_res_sx+128)); colormap(gray); title(sprintf('Sobel_y (bordes horizontales); E=%g', calcular_energia(ima_res_sx))); colorbar;
subplot(2,2,4); imagesc(uint8(ima_res_sy+128)); colormap(gray); title(sprintf('Sobel_x (bordes verticales); E=%g', calcular_energia(ima_res_sy))); colorbar;





function energia = calcular_energia(imagen)

imagen=double(imagen); % para evitar desbordamientos en caso de unit, logical, ...
energia = sum(sum(imagen .* imagen));

% Si la imagen tiene múltiples canales (por ejemplo, RGB), sumar las energías de cada canal
if size(imagen, 3) > 1
    energia = sum(energia(:));
end

end


function ima_res=imfilter_binomial(ima,orden)

triang = cell(1,orden);

triang{1} = [1 1];

for i=2:orden
    v_ant = triang{i-1};
    v=ones(1, i+1);
    v(1)=1;
    v(end)=1;
    for j=2:length(v)-1
        v(j)=v_ant(j-1) + v_ant(j);
    end
    triang{i}=v;
end
    
v= triang{orden};

% Mascara del filtro
v=double(v);
W = v'*v;

% Normalizacion
C = sum(sum(W));
W = W * (1/C);

% Filtrado
ima_res = imfilter(ima,W);
end


